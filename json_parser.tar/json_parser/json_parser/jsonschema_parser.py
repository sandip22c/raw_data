#!/usr/bin/env python
# -*- coding: utf-8 -*-

# import re
from __future__ import print_function

import json
import sys
import argparse

#from recorder import Recorder
#from validator import Validator

from py_modules.recorder import Recorder
from py_modules.validator import Validator

def usage():
    print("\nUsage: python " + sys.argv[0] + " <record|validate> <input.json> <schema.json>\n\n\tOptions:\n\trecord: Generate the schema for input.json & save in schema.json\n\tvalidate: Validate the input.json against the schema defined in schema.json\n")
    sys.exit(1)

def validateJSON(input):
    try:
        json.load(open(input, "r"))
        return True
    except Exception as err:
        print ("Failed: Json format is invalid \"{}\"".format(input))
        print (err)
        return False


def record(args):
    rec = Recorder.from_url(args.json_source)
    rec.save_json_schema(args.json_schema_file_path, indent=4)
    print("Schema generated successfully")


def validate(args):
    json_data = open(args.json_source).read()
    validator = Validator.from_path(args.json_schema_file_path)
    is_valid = validator.assert_json(json_data)

    if is_valid:
        print("Pass: \"{}\" - JSON is valid".format(args.json_source))
    else:
        if __name__ == '__main__':
            print("Failed: \"{}\" - {}".format(args.json_source, str(validator.error_message)))


def main():
    if not len(sys.argv) == 4:
        usage()

    script_name = sys.argv[0]
    action = sys.argv[1]
    json_input_file = sys.argv[2]
    schema_input_file = sys.argv[3]

    if not (action == "record") and not (action == "validate"):
        usage()
    elif action == "record":
        is_json_valid = validateJSON(json_input_file)
        if not is_json_valid:
            sys.exit(1)
    elif action == "validate":
        for file_name in json_input_file, schema_input_file:
            is_schema_valid = validateJSON(file_name)
            if not is_schema_valid:
                sys.exit(1)

    parser = argparse.ArgumentParser()

    default_parser = argparse.ArgumentParser(add_help=False)
    default_parser.add_argument('json_source', type=str, help='url or file')
    default_parser.add_argument('--path', dest='path', default='', help='set path')

    subparsers = parser.add_subparsers(help='sub-command help')

    parser_record = subparsers.add_parser('record', parents=[default_parser])
    parser_record.add_argument('json_schema_file_path', type=str, help='json schema file path')
    parser_record.set_defaults(func=record)

    parser_validate = subparsers.add_parser('validate', parents=[default_parser])
    parser_validate.add_argument('json_schema_file_path', type=str, help='json schema file path')
    parser_validate.set_defaults(func=validate)

    args = parser.parse_args()
    args.func(args)


if __name__ == '__main__':
    main()

